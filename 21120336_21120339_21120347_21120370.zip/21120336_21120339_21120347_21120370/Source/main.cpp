#include "Lab03Header.h"
int main(int argv, char* argv2[]) {
	Command_line(argv, argv2);
	return 0;
}